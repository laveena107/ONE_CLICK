package com.example.one_click;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Toast;

public class one extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_one);

        Bundle bundle = getIntent().getExtras();
        if(bundle != null) {
            if(bundle.getString("information") != null){
                Toast.makeText(getApplicationContext(),"market"+bundle.getString("information"),Toast.LENGTH_SHORT).show();
            }
        }
    }
}